import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';

const ADMIN_PIN = '5510';

export default function Admin() {
  const router = useRouter();
  const [authed, setAuthed] = useState(false);
  const [pin, setPin] = useState('');
  const [tab, setTab] = useState('dashboard');
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [addMoneyReqs, setAddMoneyReqs] = useState([]);
  const [withdrawReqs, setWithdrawReqs] = useState([]);
  const [searchPhone, setSearchPhone] = useState('');
  const [foundUser, setFoundUser] = useState(null);
  const [msg, setMsg] = useState('');

  const login = () => {
    if (pin === ADMIN_PIN) { setAuthed(true); loadData(); }
    else setMsg('❌ Wrong PIN');
  };

  const loadData = async () => {
    const r = await fetch('/api/admin/stats');
    const d = await r.json();
    if (d.success) { setStats(d.stats); setAddMoneyReqs(d.addMoneyReqs); setWithdrawReqs(d.withdrawReqs); }
  };

  const searchUser = async () => {
    const r = await fetch('/api/admin/search-user?phone=' + searchPhone);
    const d = await r.json();
    setFoundUser(d.user || null);
    if (!d.user) setMsg('❌ Not found');
  };

  const approve = async (txnId, amount, userId) => {
    const r = await fetch('/api/admin/approve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ txnId, amount, userId })
    });
    const d = await r.json();
    if (d.success) { setMsg('✅ Approved!'); loadData(); }
  };

  const reject = async (txnId, userId, amount, type) => {
    const r = await fetch('/api/admin/reject', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ txnId, userId, amount, type })
    });
    const d = await r.json();
    if (d.success) { setMsg('✅ Rejected!'); loadData(); }
  };

  const sendBonus = async () => {
    const amount = prompt('Bonus amount for ALL users:');
    if (!amount) return;
    const r = await fetch('/api/admin/bonus', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount: parseFloat(amount) })
    });
    const d = await r.json();
    setMsg(d.success ? '✅ Bonus sent!' : '❌ ' + d.message);
  };

  const toggleBan = async (userId, banned) => {
    const r = await fetch('/api/admin/ban', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, ban: !banned })
    });
    const d = await r.json();
    if (d.success) { setMsg('✅ Done!'); searchUser(); }
  };

  const adjustBalance = async (userId, type) => {
    const amount = prompt(`${type === 'add' ? 'Add' : 'Deduct'} amount:`);
    if (!amount) return;
    const r = await fetch('/api/admin/adjust-balance', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, amount: parseFloat(amount), type })
    });
    const d = await r.json();
    setMsg(d.success ? '✅ Done!' : '❌ ' + d.message);
    if (d.success) searchUser();
  };

  if (!authed) return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="card w-full max-w-sm text-center">
        <div className="text-4xl mb-3">🔐</div>
        <h1 className="text-xl font-bold text-blue-700 mb-6">Admin Panel</h1>
        <input className="input-field mb-4" type="password" placeholder="Enter PIN"
          value={pin} onChange={e => setPin(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && login()} />
        {msg && <p className="text-red-500 text-sm mb-3">{msg}</p>}
        <button className="btn-primary" onClick={login}>Login</button>
      </div>
    </div>
  );

  const tabs = [
    { id: 'dashboard', label: '📊 Dashboard' },
    { id: 'users', label: '👥 Users' },
    { id: 'addmoney', label: '➕ Add Money' },
    { id: 'withdraw', label: '💸 Withdraw' },
  ];

  return (
    <div className="min-h-screen pb-6">
      <div className="bg-gradient-to-r from-blue-700 to-blue-900 text-white p-4">
        <div className="max-w-2xl mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold">🔐 UNIO Admin</h1>
          <button onClick={sendBonus} className="text-blue-200 text-sm hover:text-white">🎁 Send Bonus</button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto">
        {/* Tabs */}
        <div className="flex overflow-x-auto gap-2 p-4">
          {tabs.map(t => (
            <button key={t.id} onClick={() => { setTab(t.id); setMsg(''); }}
              className={`whitespace-nowrap px-4 py-2 rounded-xl text-sm font-medium transition ${tab === t.id ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 border'}`}>
              {t.label}
            </button>
          ))}
        </div>

        {msg && <div className="mx-4 mb-3 p-3 bg-green-50 text-green-700 rounded-xl text-sm font-medium">{msg}</div>}

        <div className="px-4">
          {/* Dashboard */}
          {tab === 'dashboard' && stats && (
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'Total Users', value: stats.totalUsers, icon: '👥' },
                { label: 'Total Balance', value: '₹' + stats.totalBalance?.toFixed(2), icon: '💰' },
                { label: 'Pending Adds', value: stats.pendingAdds, icon: '⏳' },
                { label: 'Total Lifafa', value: stats.totalLifafa, icon: '🎁' },
              ].map((s, i) => (
                <div key={i} className="card text-center">
                  <div className="text-2xl mb-1">{s.icon}</div>
                  <p className="text-xl font-bold text-blue-700">{s.value}</p>
                  <p className="text-xs text-gray-400">{s.label}</p>
                </div>
              ))}
            </div>
          )}

          {/* Users */}
          {tab === 'users' && (
            <div className="space-y-4">
              <div className="card">
                <h3 className="font-bold mb-3">🔍 Search User</h3>
                <div className="flex gap-2">
                  <input className="input-field" placeholder="Phone number" value={searchPhone}
                    onChange={e => setSearchPhone(e.target.value)} />
                  <button onClick={searchUser} className="bg-blue-600 text-white px-4 rounded-xl">Search</button>
                </div>
              </div>
              {foundUser && (
                <div className="card">
                  <h3 className="font-bold mb-3">👤 {foundUser.name}</h3>
                  <div className="space-y-2 text-sm text-gray-600">
                    <p>📱 {foundUser.phone}</p>
                    <p>📧 {foundUser.email}</p>
                    <p>💰 Balance: ₹{foundUser.balance?.toFixed(2)}</p>
                    <p>🏦 Wallet: {foundUser.walletNumber}</p>
                    <p>📅 Joined: {new Date(foundUser.createdAt).toLocaleDateString('en-IN')}</p>
                    <p>Status: {foundUser.banned ? '🔴 Banned' : '🟢 Active'}</p>
                  </div>
                  <div className="flex gap-2 mt-4 flex-wrap">
                    <button onClick={() => toggleBan(foundUser._id, foundUser.banned)}
                      className={`px-4 py-2 rounded-xl text-sm font-medium text-white ${foundUser.banned ? 'bg-green-500' : 'bg-red-500'}`}>
                      {foundUser.banned ? '✅ Unban' : '🚫 Ban'}
                    </button>
                    <button onClick={() => adjustBalance(foundUser._id, 'add')}
                      className="bg-blue-600 text-white px-4 py-2 rounded-xl text-sm">➕ Add</button>
                    <button onClick={() => adjustBalance(foundUser._id, 'deduct')}
                      className="bg-orange-500 text-white px-4 py-2 rounded-xl text-sm">➖ Deduct</button>
                  </div>
                  {foundUser.transactions && foundUser.transactions.length > 0 && (
                    <div className="mt-4">
                      <p className="font-medium text-sm mb-2">Transaction History:</p>
                      {foundUser.transactions.map((t, i) => (
                        <div key={i} className="flex justify-between text-xs py-2 border-b">
                          <span className="capitalize">{t.type?.replace('_', ' ')}</span>
                          <span className={['add','transfer_in','bonus','lifafa'].includes(t.type) ? 'text-green-600' : 'text-red-500'}>
                            ₹{t.amount}
                          </span>
                          <span className="text-gray-400">{t.status}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Add Money Requests */}
          {tab === 'addmoney' && (
            <div className="space-y-3">
              <h3 className="font-bold text-gray-700">➕ Add Money Requests ({addMoneyReqs.length})</h3>
              {addMoneyReqs.length === 0 && <p className="text-gray-400 text-sm text-center py-8">No pending requests</p>}
              {addMoneyReqs.map((r, i) => (
                <div key={i} className="card">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <p className="font-bold">{r.name}</p>
                      <p className="text-sm text-gray-500">{r.walletNumber}</p>
                    </div>
                    <span className="bg-yellow-100 text-yellow-700 text-xs px-2 py-1 rounded">Pending</span>
                  </div>
                  <div className="text-sm text-gray-600 space-y-1 mb-3">
                    <p>📱 Mobile: {r.mobileNumber}</p>
                    <p>🔢 UTR: {r.utrNumber}</p>
                    <p>📅 {new Date(r.createdAt).toLocaleDateString('en-IN')}</p>
                  </div>
                  <div className="flex gap-2">
                    <div className="flex-1">
                      <input className="input-field text-sm py-2" type="number" placeholder="Amount to add"
                        id={'amt-' + r._id} />
                    </div>
                    <button onClick={() => approve(r._id, parseFloat(document.getElementById('amt-' + r._id).value), r.userId)}
                      className="bg-green-500 text-white px-4 py-2 rounded-xl text-sm font-medium">✅ Approve</button>
                    <button onClick={() => reject(r._id, r.userId, 0, 'add')}
                      className="bg-red-500 text-white px-4 py-2 rounded-xl text-sm font-medium">❌ Reject</button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Withdraw Requests */}
          {tab === 'withdraw' && (
            <div className="space-y-3">
              <h3 className="font-bold text-gray-700">💸 Withdrawal Requests ({withdrawReqs.length})</h3>
              {withdrawReqs.length === 0 && <p className="text-gray-400 text-sm text-center py-8">No pending requests</p>}
              {withdrawReqs.map((r, i) => (
                <div key={i} className="card">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <p className="font-bold">{r.name}</p>
                      <p className="text-sm text-gray-500">{r.walletNumber}</p>
                    </div>
                    <span className="text-blue-700 font-bold text-lg">₹{r.amount}</span>
                  </div>
                  <div className="text-sm text-gray-600 space-y-1 mb-3">
                    <p>💳 UPI: {r.upiId}</p>
                    <p>📅 {new Date(r.createdAt).toLocaleDateString('en-IN')}</p>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => approve(r._id, r.amount, r.userId)}
                      className="flex-1 bg-green-500 text-white py-2 rounded-xl text-sm font-medium">✅ Approve</button>
                    <button onClick={() => reject(r._id, r.userId, r.amount, 'withdraw')}
                      className="flex-1 bg-red-500 text-white py-2 rounded-xl text-sm font-medium">❌ Reject (Refund)</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
