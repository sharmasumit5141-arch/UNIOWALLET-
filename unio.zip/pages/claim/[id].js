import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';

export default function Claim() {
  const router = useRouter();
  const { id } = router.query;
  const [lifafa, setLifafa] = useState(null);
  const [phone, setPhone] = useState('');
  const [step, setStep] = useState('phone');
  const [verifying, setVerifying] = useState(false);
  const [channelStatus, setChannelStatus] = useState([]);
  const [msg, setMsg] = useState('');
  const [reward, setReward] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    fetch('/api/lifafa/get?id=' + id).then(r => r.json()).then(d => {
      if (d.success) {
        setLifafa(d.lifafa);
        setChannelStatus(d.lifafa.channels.map(c => ({ ...c, verified: false })));
      }
      setLoading(false);
    });
  }, [id]);

  const verifyChannel = async (idx) => {
    if (!phone) { setMsg('❌ Enter phone first'); return; }
    setVerifying(true);
    const res = await fetch('/api/lifafa/verify-channel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone, channelUsername: channelStatus[idx].username, lifafaId: id })
    });
    const d = await res.json();
    if (d.verified) {
      const updated = [...channelStatus];
      updated[idx].verified = true;
      setChannelStatus(updated);
    } else {
      setMsg('❌ Not joined: ' + channelStatus[idx].username);
    }
    setVerifying(false);
  };

  const claim = async () => {
    const allVerified = channelStatus.every(c => c.verified);
    if (!allVerified) { setMsg('❌ Verify all channels first'); return; }
    setLoading(true);
    const res = await fetch('/api/lifafa/claim', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone, lifafaId: id })
    });
    const d = await res.json();
    if (d.success) { setReward(d.amount); setStep('success'); }
    else setMsg('❌ ' + d.message);
    setLoading(false);
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-blue-600 text-xl">Loading... 💙</div>
    </div>
  );

  if (!lifafa) return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="card text-center"><p className="text-red-500">❌ Lifafa not found or expired</p></div>
    </div>
  );

  const claimed = lifafa.claimedBy?.length || 0;
  const remaining = lifafa.totalUsers - claimed;
  const siteName = lifafa.siteName || 'UNIO';

  if (step === 'success') return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="card text-center max-w-sm w-full">
        <div className="text-6xl mb-4">🎉</div>
        <h2 className="text-2xl font-bold text-green-600">Congratulations!</h2>
        <p className="text-gray-500 mt-2">You received</p>
        <p className="text-4xl font-bold text-blue-700 my-3">₹{reward}</p>
        <p className="text-sm text-gray-400">from {siteName} Wallet</p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="card max-w-sm w-full">
        <div className="text-center mb-6">
          <div className="text-4xl mb-2">🎁</div>
          <h1 className="text-xl font-bold text-blue-700">{siteName} Wallet</h1>
          <p className="text-gray-500 text-sm capitalize">{lifafa.type} Lifafa</p>
          <div className="flex justify-center gap-4 mt-3">
            <div className="text-center">
              <p className="text-green-600 font-bold">{claimed}</p>
              <p className="text-xs text-gray-400">Claimed</p>
            </div>
            <div className="text-center">
              <p className="text-blue-600 font-bold">{remaining}</p>
              <p className="text-xs text-gray-400">Remaining</p>
            </div>
          </div>
        </div>

        {remaining <= 0 ? (
          <p className="text-center text-red-500 font-medium">❌ All claimed!</p>
        ) : (
          <div className="space-y-4">
            <input className="input-field" placeholder="Enter your mobile number" value={phone}
              onChange={e => setPhone(e.target.value)} />

            <div>
              <p className="text-sm font-medium text-gray-700 mb-2">Join channels to claim:</p>
              {channelStatus.map((ch, i) => (
                <div key={i} className="flex items-center gap-2 mb-2 p-3 bg-gray-50 rounded-xl">
                  <div className="flex-1">
                    <p className="text-sm font-medium">@{ch.username}</p>
                    <a href={ch.link} target="_blank" className="text-blue-600 text-xs">Join Channel →</a>
                  </div>
                  {ch.verified ? (
                    <span className="text-green-500 font-bold">✅</span>
                  ) : (
                    <button onClick={() => verifyChannel(i)} disabled={verifying}
                      className="bg-blue-600 text-white text-xs px-3 py-1.5 rounded-lg">
                      {verifying ? '...' : 'Verify'}
                    </button>
                  )}
                </div>
              ))}
            </div>

            {msg && <p className="text-sm text-red-500">{msg}</p>}

            <button onClick={claim} className="btn-primary" disabled={loading}>
              {loading ? 'Claiming...' : '🎁 Claim Now'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
