import { useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';

export default function Register() {
  const router = useRouter();
  const [form, setForm] = useState({ name: '', email: '', telegramId: '', phone: '', password: '' });
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const handle = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMsg('');
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    });
    const data = await res.json();
    if (data.success) {
      setMsg('✅ Registered! Redirecting...');
      setTimeout(() => router.push('/login'), 1500);
    } else {
      setMsg('❌ ' + data.message);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="card w-full max-w-md">
        <div className="text-center mb-8">
          <div className="text-4xl mb-2">💙</div>
          <h1 className="text-2xl font-bold text-blue-700">UNIO Wallet</h1>
          <p className="text-gray-500 text-sm">Create your account</p>
        </div>

        <form onSubmit={handle} className="space-y-4">
          <input className="input-field" placeholder="Full Name" value={form.name}
            onChange={e => setForm({...form, name: e.target.value})} required />
          <input className="input-field" type="email" placeholder="Email" value={form.email}
            onChange={e => setForm({...form, email: e.target.value})} required />
          <input className="input-field" placeholder="Telegram ID (numbers only)" value={form.telegramId}
            onChange={e => setForm({...form, telegramId: e.target.value.replace(/\D/g, '')})} required />
          <input className="input-field" placeholder="Phone Number" value={form.phone}
            onChange={e => setForm({...form, phone: e.target.value})} required />
          <input className="input-field" type="password" placeholder="Password" value={form.password}
            onChange={e => setForm({...form, password: e.target.value})} required />

          {msg && <div className={`text-center text-sm font-medium ${msg.startsWith('✅') ? 'text-green-600' : 'text-red-500'}`}>{msg}</div>}

          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? 'Creating...' : 'Create Account'}
          </button>
        </form>

        <p className="text-center text-sm text-gray-500 mt-4">
          Already have account? <Link href="/login" className="text-blue-600 font-medium">Login</Link>
        </p>
      </div>
    </div>
  );
}
