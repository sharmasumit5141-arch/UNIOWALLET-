import { connectDB } from '../../lib/db';
import User from '../../models/User';
import Transaction from '../../models/Transaction';
import { v4 as uuid } from 'uuid';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  await connectDB();
  const { api_key, wallet_number, amount, note } = req.body;
  const user = await User.findOne({ apiKey: api_key, walletNumber: wallet_number });
  if (!user) return res.json({ status: 'error', message: 'Invalid credentials' });
  const amt = parseFloat(amount);
  if (user.balance < amt) return res.json({ status: 'error', message: 'Insufficient balance' });
  user.balance -= amt;
  await user.save();
  await Transaction.create({ userId: user._id, walletNumber: user.walletNumber, name: user.name, type: 'withdraw', amount: amt, status: 'approved', note, transactionId: uuid() });
  res.json({ status: 'success', wallet_number: user.walletNumber, balance: user.balance, message: 'Deducted' });
}
