import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import bcrypt from 'bcryptjs';
import { v4 as uuid } from 'uuid';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  await connectDB();

  const { name, email, telegramId, phone, password } = req.body;
  if (!name || !email || !telegramId || !phone || !password)
    return res.json({ success: false, message: 'All fields required' });

  const exists = await User.findOne({ $or: [{ email }, { phone }] });
  if (exists) return res.json({ success: false, message: 'Email or phone already registered' });

  const hashed = await bcrypt.hash(password, 10);
  const walletNumber = 'UW' + Math.floor(Math.random() * 9000000000 + 1000000000);
  const apiKey = 'UNIO-' + uuid().replace(/-/g, '').toUpperCase();

  await User.create({ name, email, telegramId, phone, password: hashed, walletNumber, apiKey });
  res.json({ success: true, message: 'Registered!' });
}
