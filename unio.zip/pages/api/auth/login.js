import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import bcrypt from 'bcryptjs';
import { signToken } from '../../../lib/auth';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  await connectDB();

  const { phone, password } = req.body;
  const user = await User.findOne({ phone });
  if (!user) return res.json({ success: false, message: 'User not found' });
  if (user.banned) return res.json({ success: false, message: 'Account banned' });

  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.json({ success: false, message: 'Wrong password' });

  const token = signToken({ id: user._id, walletNumber: user.walletNumber });
  res.json({ success: true, token });
}
