import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Transaction from '../../../models/Transaction';
import { verifyToken, getTokenFromReq } from '../../../lib/auth';
import { v4 as uuid } from 'uuid';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  await connectDB();
  const decoded = verifyToken(getTokenFromReq(req));
  if (!decoded) return res.json({ success: false, message: 'Unauthorized' });

  const user = await User.findById(decoded.id);
  const { upiId, amount } = req.body;
  const amt = parseFloat(amount);

  if (!upiId || !amount) return res.json({ success: false, message: 'All fields required' });
  if (amt < 10) return res.json({ success: false, message: 'Minimum ₹10' });
  if (user.balance < amt) return res.json({ success: false, message: 'Insufficient balance' });

  user.balance -= amt;
  await user.save();

  await Transaction.create({
    userId: user._id, walletNumber: user.walletNumber, name: user.name,
    type: 'withdraw', amount: amt, status: 'pending',
    upiId, transactionId: uuid()
  });

  res.json({ success: true, message: 'Withdrawal request submitted' });
}
