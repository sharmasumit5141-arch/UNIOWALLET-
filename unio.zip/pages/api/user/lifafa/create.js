import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Lifafa from '../../../models/Lifafa';
import { verifyToken, getTokenFromReq } from '../../../lib/auth';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  await connectDB();
  const decoded = verifyToken(getTokenFromReq(req));
  if (!decoded) return res.json({ success: false, message: 'Unauthorized' });

  const user = await User.findById(decoded.id);
  const { type, totalUsers, perUserAmount, minAmount, maxAmount, rewardRange, channels } = req.body;

  if (!type || !totalUsers) return res.json({ success: false, message: 'Required fields missing' });
  if (!channels || channels.length < 1) return res.json({ success: false, message: 'At least 1 channel required' });

  // Check balance
  let totalCost = 0;
  if (type === 'normal') totalCost = parseFloat(perUserAmount) * parseInt(totalUsers);
  if (type === 'toss') totalCost = parseFloat(maxAmount) * parseInt(totalUsers);
  if (type === 'scratch') totalCost = 100; // placeholder

  if (user.balance < totalCost) return res.json({ success: false, message: 'Insufficient balance' });

  user.balance -= totalCost;
  await user.save();

  const host = req.headers.host || 'unio-wallet.vercel.app';
  const siteName = host.split('.')[0].toUpperCase();
  const lifafa = await Lifafa.create({
    creatorId: user._id, type, totalUsers: parseInt(totalUsers),
    perUserAmount: parseFloat(perUserAmount) || 0,
    minAmount: parseFloat(minAmount) || 0,
    maxAmount: parseFloat(maxAmount) || 0,
    rewardRange, channels, siteName
  });

  const claimUrl = `https://${host}/claim/${lifafa._id}`;
  lifafa.claimUrl = claimUrl;
  await lifafa.save();

  res.json({ success: true, claimUrl });
}
