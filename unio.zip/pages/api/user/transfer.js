import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Transaction from '../../../models/Transaction';
import { verifyToken, getTokenFromReq } from '../../../lib/auth';
import { v4 as uuid } from 'uuid';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  await connectDB();
  const decoded = verifyToken(getTokenFromReq(req));
  if (!decoded) return res.json({ success: false, message: 'Unauthorized' });

  const sender = await User.findById(decoded.id);
  const { toWallet, amount } = req.body;
  const amt = parseFloat(amount);

  if (!toWallet || !amount) return res.json({ success: false, message: 'All fields required' });
  if (toWallet === sender.walletNumber) return res.json({ success: false, message: 'Cannot transfer to self' });
  if (sender.balance < amt) return res.json({ success: false, message: 'Insufficient balance' });

  const receiver = await User.findOne({ walletNumber: toWallet });
  if (!receiver) return res.json({ success: false, message: 'Wallet not found' });

  const txnId = uuid();
  sender.balance -= amt;
  receiver.balance += amt;
  await sender.save();
  await receiver.save();

  await Transaction.create({ userId: sender._id, walletNumber: sender.walletNumber, name: sender.name, type: 'transfer_out', amount: amt, status: 'approved', toWallet, transactionId: txnId });
  await Transaction.create({ userId: receiver._id, walletNumber: receiver.walletNumber, name: receiver.name, type: 'transfer_in', amount: amt, status: 'approved', fromWallet: sender.walletNumber, transactionId: txnId });

  res.json({ success: true, message: 'Transfer successful', wallet_number: sender.walletNumber, balance: sender.balance });
}
