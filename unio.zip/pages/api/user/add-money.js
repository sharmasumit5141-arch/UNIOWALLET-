import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Transaction from '../../../models/Transaction';
import { verifyToken, getTokenFromReq } from '../../../lib/auth';
import { v4 as uuid } from 'uuid';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  await connectDB();
  const decoded = verifyToken(getTokenFromReq(req));
  if (!decoded) return res.json({ success: false, message: 'Unauthorized' });

  const user = await User.findById(decoded.id);
  const { utrNumber, mobileNumber } = req.body;
  if (!utrNumber || !mobileNumber) return res.json({ success: false, message: 'All fields required' });

  await Transaction.create({
    userId: user._id, walletNumber: user.walletNumber, name: user.name,
    type: 'add', amount: 0, status: 'pending',
    utrNumber, mobileNumber, transactionId: uuid()
  });

  res.json({ success: true, message: 'Request submitted' });
}
