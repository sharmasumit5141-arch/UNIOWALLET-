import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Transaction from '../../../models/Transaction';
import { verifyToken, getTokenFromReq } from '../../../lib/auth';

export default async function handler(req, res) {
  await connectDB();
  const token = getTokenFromReq(req);
  const decoded = verifyToken(token);
  if (!decoded) return res.json({ success: false, message: 'Unauthorized' });

  const user = await User.findById(decoded.id).select('-password');
  if (!user) return res.json({ success: false, message: 'Not found' });

  const transactions = await Transaction.find({ userId: user._id }).sort({ createdAt: -1 }).limit(20);
  res.json({ success: true, user, transactions });
}
