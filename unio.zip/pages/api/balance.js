import { connectDB } from '../../lib/db';
import User from '../../models/User';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  await connectDB();
  const { api_key, wallet_number } = req.body;
  const user = await User.findOne({ apiKey: api_key, walletNumber: wallet_number });
  if (!user) return res.json({ status: 'error', message: 'Invalid API key or wallet number' });
  res.json({ status: 'success', wallet_number: user.walletNumber, balance: user.balance, message: 'Balance fetched' });
}
