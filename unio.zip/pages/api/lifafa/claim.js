import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Lifafa from '../../../models/Lifafa';
import Transaction from '../../../models/Transaction';
import { v4 as uuid } from 'uuid';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  await connectDB();

  const { phone, lifafaId } = req.body;
  const user = await User.findOne({ phone });
  if (!user) return res.json({ success: false, message: 'User not found. Register first.' });

  const lifafa = await Lifafa.findById(lifafaId);
  if (!lifafa || !lifafa.active) return res.json({ success: false, message: 'Lifafa expired' });

  const alreadyClaimed = lifafa.claimedBy.some(c => c.userId.toString() === user._id.toString());
  if (alreadyClaimed) return res.json({ success: false, message: 'Already claimed' });

  if (lifafa.claimedBy.length >= lifafa.totalUsers) return res.json({ success: false, message: 'All claimed!' });

  let amount = 0;
  if (lifafa.type === 'normal') amount = lifafa.perUserAmount;
  if (lifafa.type === 'toss') {
    const win = Math.random() > 0.5;
    amount = win ? lifafa.maxAmount : lifafa.minAmount;
  }
  if (lifafa.type === 'scratch') {
    const [min, max] = lifafa.rewardRange.split('-').map(Number);
    amount = Math.floor(Math.random() * (max - min + 1)) + min;
  }

  user.balance += amount;
  await user.save();

  lifafa.claimedBy.push({ userId: user._id, amount, claimedAt: new Date() });
  if (lifafa.claimedBy.length >= lifafa.totalUsers) lifafa.active = false;
  await lifafa.save();

  await Transaction.create({
    userId: user._id, walletNumber: user.walletNumber, name: user.name,
    type: 'lifafa', amount, status: 'approved', transactionId: uuid()
  });

  res.json({ success: true, amount });
}
