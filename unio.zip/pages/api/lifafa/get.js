import { connectDB } from '../../../lib/db';
import Lifafa from '../../../models/Lifafa';

export default async function handler(req, res) {
  await connectDB();
  const { id } = req.query;
  const lifafa = await Lifafa.findById(id);
  if (!lifafa) return res.json({ success: false });
  res.json({ success: true, lifafa });
}
