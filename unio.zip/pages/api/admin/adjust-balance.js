import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Transaction from '../../../models/Transaction';
import { v4 as uuid } from 'uuid';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  await connectDB();
  const { userId, amount, type } = req.body;
  const user = await User.findById(userId);
  if (!user) return res.json({ success: false, message: 'User not found' });
  const amt = parseFloat(amount);
  if (type === 'add') user.balance += amt;
  else if (type === 'deduct') {
    if (user.balance < amt) return res.json({ success: false, message: 'Insufficient balance' });
    user.balance -= amt;
  }
  await user.save();
  await Transaction.create({ userId: user._id, walletNumber: user.walletNumber, name: user.name, type: type === 'add' ? 'bonus' : 'withdraw', amount: amt, status: 'approved', note: 'Admin adjustment', transactionId: uuid() });
  res.json({ success: true, balance: user.balance });
}
