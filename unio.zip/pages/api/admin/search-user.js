import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Transaction from '../../../models/Transaction';

export default async function handler(req, res) {
  await connectDB();
  const { phone } = req.query;
  const user = await User.findOne({ phone }).select('-password');
  if (!user) return res.json({ user: null });
  const transactions = await Transaction.find({ userId: user._id }).sort({ createdAt: -1 }).limit(20);
  res.json({ user: { ...user.toObject(), transactions } });
}
