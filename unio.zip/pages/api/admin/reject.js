import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Transaction from '../../../models/Transaction';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  await connectDB();
  const { txnId, userId, amount, type } = req.body;
  const txn = await Transaction.findById(txnId);
  if (!txn) return res.json({ success: false });
  txn.status = 'rejected';
  await txn.save();
  // Refund on withdraw reject
  if (type === 'withdraw' && amount > 0) {
    await User.findByIdAndUpdate(userId, { $inc: { balance: parseFloat(amount) } });
  }
  res.json({ success: true });
}
