import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Transaction from '../../../models/Transaction';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  await connectDB();
  const { txnId, amount, userId } = req.body;
  const txn = await Transaction.findById(txnId);
  if (!txn) return res.json({ success: false, message: 'Not found' });
  txn.status = 'approved';
  txn.amount = parseFloat(amount);
  await txn.save();
  if (txn.type === 'add') {
    await User.findByIdAndUpdate(userId, { $inc: { balance: parseFloat(amount) } });
  }
  res.json({ success: true });
}
