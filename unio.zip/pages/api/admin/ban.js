import { connectDB } from '../../../lib/db';
import User from '../../../models/User';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  await connectDB();
  const { userId, ban } = req.body;
  await User.findByIdAndUpdate(userId, { banned: ban });
  res.json({ success: true });
}
