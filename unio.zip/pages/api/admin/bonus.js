import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Transaction from '../../../models/Transaction';
import { v4 as uuid } from 'uuid';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  await connectDB();
  const { amount } = req.body;
  const users = await User.find({ banned: false });
  for (const user of users) {
    user.balance += parseFloat(amount);
    await user.save();
    await Transaction.create({ userId: user._id, walletNumber: user.walletNumber, name: user.name, type: 'bonus', amount: parseFloat(amount), status: 'approved', transactionId: uuid() });
  }
  res.json({ success: true, count: users.length });
}
