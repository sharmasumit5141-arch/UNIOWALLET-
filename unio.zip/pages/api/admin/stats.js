import { connectDB } from '../../../lib/db';
import User from '../../../models/User';
import Transaction from '../../../models/Transaction';
import Lifafa from '../../../models/Lifafa';

export default async function handler(req, res) {
  await connectDB();
  const totalUsers = await User.countDocuments();
  const users = await User.find();
  const totalBalance = users.reduce((sum, u) => sum + (u.balance || 0), 0);
  const addMoneyReqs = await Transaction.find({ type: 'add', status: 'pending' }).sort({ createdAt: -1 });
  const withdrawReqs = await Transaction.find({ type: 'withdraw', status: 'pending' }).sort({ createdAt: -1 });
  const totalLifafa = await Lifafa.countDocuments();
  res.json({ success: true, stats: { totalUsers, totalBalance, pendingAdds: addMoneyReqs.length, totalLifafa }, addMoneyReqs, withdrawReqs });
}
