import { useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';

export default function Login() {
  const router = useRouter();
  const [form, setForm] = useState({ phone: '', password: '' });
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const handle = async (e) => {
    e.preventDefault();
    setLoading(true);
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    });
    const data = await res.json();
    if (data.success) {
      localStorage.setItem('token', data.token);
      router.push('/dashboard');
    } else {
      setMsg('❌ ' + data.message);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="card w-full max-w-md">
        <div className="text-center mb-8">
          <div className="text-4xl mb-2">💙</div>
          <h1 className="text-2xl font-bold text-blue-700">UNIO Wallet</h1>
          <p className="text-gray-500 text-sm">Login to your wallet</p>
        </div>

        <form onSubmit={handle} className="space-y-4">
          <input className="input-field" placeholder="Phone Number" value={form.phone}
            onChange={e => setForm({...form, phone: e.target.value})} required />
          <input className="input-field" type="password" placeholder="Password" value={form.password}
            onChange={e => setForm({...form, password: e.target.value})} required />

          {msg && <div className="text-center text-sm text-red-500 font-medium">{msg}</div>}

          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </form>

        <p className="text-center text-sm text-gray-500 mt-4">
          No account? <Link href="/register" className="text-blue-600 font-medium">Register</Link>
        </p>

        <div className="text-center mt-4">
          <Link href="/admin" className="text-xs text-gray-400 hover:text-gray-600">Admin Panel</Link>
        </div>
      </div>
    </div>
  );
}
