import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';

const tabs = ['Balance', 'Add Money', 'Withdraw', 'Transfer', 'API Keys', 'Lifafa', 'Help'];
const icons = ['💰', '➕', '💸', '🔄', '🔑', '🎁', '❓'];

export default function Dashboard() {
  const router = useRouter();
  const [tab, setTab] = useState(0);
  const [user, setUser] = useState(null);
  const [txns, setTxns] = useState([]);
  const [loading, setLoading] = useState(true);

  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;

  useEffect(() => {
    if (!token) { router.push('/login'); return; }
    fetch('/api/user/me', { headers: { Authorization: 'Bearer ' + token } })
      .then(r => r.json()).then(d => {
        if (!d.success) { router.push('/login'); return; }
        setUser(d.user);
        setTxns(d.transactions || []);
        setLoading(false);
      });
  }, []);

  const logout = () => { localStorage.removeItem('token'); router.push('/login'); };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-blue-600 text-xl">Loading... 💙</div>
    </div>
  );

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-4">
        <div className="flex justify-between items-center max-w-lg mx-auto">
          <div>
            <p className="text-blue-200 text-sm">Welcome back</p>
            <h2 className="text-xl font-bold">{user?.name} 👋</h2>
          </div>
          <button onClick={logout} className="text-blue-200 text-sm hover:text-white">Logout</button>
        </div>
      </div>

      <div className="max-w-lg mx-auto p-4">
        {/* Tab Content */}
        {tab === 0 && <BalanceTab user={user} txns={txns} />}
        {tab === 1 && <AddMoneyTab token={token} />}
        {tab === 2 && <WithdrawTab token={token} balance={user?.balance} />}
        {tab === 3 && <TransferTab token={token} balance={user?.balance} />}
        {tab === 4 && <APIKeysTab user={user} />}
        {tab === 5 && <LifafaTab token={token} user={user} />}
        {tab === 6 && <HelpTab />}
      </div>

      {/* Bottom Nav */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 shadow-lg">
        <div className="flex justify-around max-w-lg mx-auto">
          {tabs.map((t, i) => (
            <button key={i} onClick={() => setTab(i)}
              className={`flex flex-col items-center py-2 px-1 text-xs transition-colors ${tab === i ? 'text-blue-600' : 'text-gray-400'}`}>
              <span className="text-lg">{icons[i]}</span>
              <span className="mt-0.5 hidden sm:block">{t}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function BalanceTab({ user, txns }) {
  return (
    <div className="space-y-4 mt-4">
      <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl p-6 text-white">
        <p className="text-blue-200 text-sm">Total Balance</p>
        <p className="text-4xl font-bold mt-1">₹{user?.balance?.toFixed(2)}</p>
        <div className="mt-4 pt-4 border-t border-blue-500">
          <p className="text-blue-200 text-xs">Wallet Number</p>
          <p className="font-mono font-bold">{user?.walletNumber}</p>
        </div>
      </div>

      <div className="card">
        <h3 className="font-bold text-gray-700 mb-3">Recent Transactions</h3>
        {txns.length === 0 ? <p className="text-gray-400 text-sm text-center py-4">No transactions yet</p> :
          txns.slice(0, 10).map((t, i) => (
            <div key={i} className="flex justify-between items-center py-3 border-b border-gray-50 last:border-0">
              <div>
                <p className="text-sm font-medium text-gray-700 capitalize">{t.type?.replace('_', ' ')}</p>
                <p className="text-xs text-gray-400">{new Date(t.createdAt).toLocaleDateString('en-IN')}</p>
              </div>
              <div className="text-right">
                <p className={`font-bold ${['add','transfer_in','bonus','lifafa'].includes(t.type) ? 'text-green-600' : 'text-red-500'}`}>
                  {['add','transfer_in','bonus','lifafa'].includes(t.type) ? '+' : '-'}₹{t.amount}
                </p>
                <p className={`text-xs ${t.status === 'approved' ? 'text-green-500' : t.status === 'rejected' ? 'text-red-400' : 'text-yellow-500'}`}>
                  {t.status}
                </p>
              </div>
            </div>
          ))
        }
      </div>
    </div>
  );
}

function AddMoneyTab({ token }) {
  const [form, setForm] = useState({ utrNumber: '', mobileNumber: '' });
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const res = await fetch('/api/user/add-money', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
      body: JSON.stringify(form)
    });
    const d = await res.json();
    setMsg(d.success ? '✅ Request submitted! Admin will approve soon.' : '❌ ' + d.message);
    setLoading(false);
    if (d.success) setForm({ utrNumber: '', mobileNumber: '' });
  };

  return (
    <div className="space-y-4 mt-4">
      <div className="card bg-blue-50 border-blue-100">
        <p className="text-sm text-gray-600 mb-1">Send money to UPI ID:</p>
        <p className="text-xl font-bold text-blue-700 font-mono">Sumit302010@fam</p>
        <p className="text-xs text-gray-500 mt-1">Then submit UTR below</p>
      </div>
      <div className="card">
        <h3 className="font-bold text-gray-700 mb-4">Add Money Request</h3>
        <form onSubmit={submit} className="space-y-4">
          <input className="input-field" placeholder="UTR Number" value={form.utrNumber}
            onChange={e => setForm({...form, utrNumber: e.target.value})} required />
          <input className="input-field" placeholder="Your Mobile Number" value={form.mobileNumber}
            onChange={e => setForm({...form, mobileNumber: e.target.value})} required />
          {msg && <p className={`text-sm font-medium ${msg.startsWith('✅') ? 'text-green-600' : 'text-red-500'}`}>{msg}</p>}
          <button type="submit" className="btn-primary" disabled={loading}>{loading ? 'Submitting...' : 'Submit Request'}</button>
        </form>
      </div>
    </div>
  );
}

function WithdrawTab({ token, balance }) {
  const [form, setForm] = useState({ upiId: '', amount: '' });
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (parseInt(form.amount) < 10) { setMsg('❌ Minimum ₹10 withdraw'); return; }
    setLoading(true);
    const res = await fetch('/api/user/withdraw', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
      body: JSON.stringify(form)
    });
    const d = await res.json();
    setMsg(d.success ? '✅ Withdrawal request submitted!' : '❌ ' + d.message);
    setLoading(false);
    if (d.success) setForm({ upiId: '', amount: '' });
  };

  return (
    <div className="space-y-4 mt-4">
      <div className="card bg-blue-50 border-blue-100">
        <p className="text-sm text-gray-600">Available Balance</p>
        <p className="text-2xl font-bold text-blue-700">₹{balance?.toFixed(2)}</p>
      </div>
      <div className="card">
        <h3 className="font-bold text-gray-700 mb-4">Withdraw Money</h3>
        <form onSubmit={submit} className="space-y-4">
          <input className="input-field" placeholder="Your UPI ID" value={form.upiId}
            onChange={e => setForm({...form, upiId: e.target.value})} required />
          <input className="input-field" type="number" placeholder="Amount (Min ₹10)" value={form.amount}
            onChange={e => setForm({...form, amount: e.target.value})} required />
          {msg && <p className={`text-sm font-medium ${msg.startsWith('✅') ? 'text-green-600' : 'text-red-500'}`}>{msg}</p>}
          <button type="submit" className="btn-primary" disabled={loading}>{loading ? 'Processing...' : 'Withdraw'}</button>
        </form>
      </div>
    </div>
  );
}

function TransferTab({ token, balance }) {
  const [form, setForm] = useState({ toWallet: '', amount: '' });
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const res = await fetch('/api/user/transfer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
      body: JSON.stringify(form)
    });
    const d = await res.json();
    setMsg(d.success ? '✅ Transfer successful!' : '❌ ' + d.message);
    setLoading(false);
    if (d.success) setForm({ toWallet: '', amount: '' });
  };

  return (
    <div className="space-y-4 mt-4">
      <div className="card bg-blue-50 border-blue-100">
        <p className="text-sm text-gray-600">Available Balance</p>
        <p className="text-2xl font-bold text-blue-700">₹{balance?.toFixed(2)}</p>
      </div>
      <div className="card">
        <h3 className="font-bold text-gray-700 mb-4">Transfer Money</h3>
        <form onSubmit={submit} className="space-y-4">
          <input className="input-field" placeholder="Receiver Wallet Number (UW...)" value={form.toWallet}
            onChange={e => setForm({...form, toWallet: e.target.value})} required />
          <input className="input-field" type="number" placeholder="Amount" value={form.amount}
            onChange={e => setForm({...form, amount: e.target.value})} required />
          {msg && <p className={`text-sm font-medium ${msg.startsWith('✅') ? 'text-green-600' : 'text-red-500'}`}>{msg}</p>}
          <button type="submit" className="btn-primary" disabled={loading}>{loading ? 'Transferring...' : 'Transfer'}</button>
        </form>
      </div>
    </div>
  );
}

function APIKeysTab({ user }) {
  const [copied, setCopied] = useState(false);
  const copy = (text) => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); };

  return (
    <div className="space-y-4 mt-4">
      <div className="card">
        <h3 className="font-bold text-gray-700 mb-4">🔑 Your API Key</h3>
        <div className="bg-gray-50 rounded-xl p-4 font-mono text-sm break-all text-gray-700">{user?.apiKey}</div>
        <button onClick={() => copy(user?.apiKey)} className="btn-secondary mt-3">{copied ? '✅ Copied!' : 'Copy API Key'}</button>
      </div>

      <div className="card">
        <h3 className="font-bold text-gray-700 mb-3">API Endpoints</h3>
        {[
          { method: 'POST', path: '/api/balance', desc: 'Check balance' },
          { method: 'POST', path: '/api/add-money', desc: 'Add money' },
          { method: 'POST', path: '/api/deduct-money', desc: 'Deduct money' },
          { method: 'POST', path: '/api/transfer', desc: 'Transfer' },
        ].map((ep, i) => (
          <div key={i} className="flex items-center gap-3 py-2 border-b border-gray-50 last:border-0">
            <span className="bg-blue-100 text-blue-700 text-xs font-bold px-2 py-1 rounded">{ep.method}</span>
            <div>
              <p className="font-mono text-xs text-gray-700">{ep.path}</p>
              <p className="text-xs text-gray-400">{ep.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function LifafaTab({ token, user }) {
  const [step, setStep] = useState('menu');
  const [type, setType] = useState('');
  const [form, setForm] = useState({ totalUsers: '', perUserAmount: '', minAmount: '', maxAmount: '', rewardRange: '' });
  const [channels, setChannels] = useState([{ username: '', link: '' }]);
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const addChannel = () => { if (channels.length < 15) setChannels([...channels, { username: '', link: '' }]); };
  const removeChannel = (i) => setChannels(channels.filter((_, idx) => idx !== i));

  const submit = async () => {
    setLoading(true);
    const res = await fetch('/api/user/lifafa/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
      body: JSON.stringify({ type, ...form, channels })
    });
    const d = await res.json();
    if (d.success) {
      setMsg('✅ Lifafa created! URL: ' + d.claimUrl);
      setStep('menu');
    } else {
      setMsg('❌ ' + d.message);
    }
    setLoading(false);
  };

  if (step === 'menu') return (
    <div className="space-y-4 mt-4">
      <div className="card">
        <h3 className="font-bold text-gray-700 mb-4">🎁 Create Lifafa</h3>
        {msg && <p className="text-sm font-medium text-green-600 mb-3 break-all">{msg}</p>}
        <div className="space-y-3">
          {[['scratch','🎰 Scratch Card'],['toss','🪙 Toss'],['normal','🎁 Normal']].map(([t, label]) => (
            <button key={t} onClick={() => { setType(t); setStep('form'); setMsg(''); }}
              className="btn-secondary text-left">{label}</button>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-4 mt-4">
      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <button onClick={() => setStep('menu')} className="text-blue-600">← Back</button>
          <h3 className="font-bold text-gray-700 capitalize">{type} Lifafa</h3>
        </div>

        <div className="space-y-3">
          <input className="input-field" type="number" placeholder="Total Users" value={form.totalUsers}
            onChange={e => setForm({...form, totalUsers: e.target.value})} />
          {type === 'normal' && <input className="input-field" type="number" placeholder="Per User Amount (₹)" value={form.perUserAmount}
            onChange={e => setForm({...form, perUserAmount: e.target.value})} />}
          {type === 'toss' && <>
            <input className="input-field" type="number" placeholder="Min Amount (₹)" value={form.minAmount}
              onChange={e => setForm({...form, minAmount: e.target.value})} />
            <input className="input-field" type="number" placeholder="Max Amount (₹)" value={form.maxAmount}
              onChange={e => setForm({...form, maxAmount: e.target.value})} />
          </>}
          {type === 'scratch' && <input className="input-field" placeholder="Reward Range (e.g. 5-50)" value={form.rewardRange}
            onChange={e => setForm({...form, rewardRange: e.target.value})} />}

          <div>
            <p className="text-sm font-medium text-gray-700 mb-2">Channels (1-15):</p>
            {channels.map((ch, i) => (
              <div key={i} className="flex gap-2 mb-2">
                <input className="input-field" placeholder="@username" value={ch.username}
                  onChange={e => { const c=[...channels]; c[i].username=e.target.value; setChannels(c); }} />
                <input className="input-field" placeholder="Link" value={ch.link}
                  onChange={e => { const c=[...channels]; c[i].link=e.target.value; setChannels(c); }} />
                {i > 0 && <button onClick={() => removeChannel(i)} className="text-red-400 text-xl">×</button>}
              </div>
            ))}
            {channels.length < 15 && <button onClick={addChannel} className="text-blue-600 text-sm">+ Add Channel</button>}
          </div>

          {msg && <p className="text-sm text-red-500">{msg}</p>}
          <button onClick={submit} className="btn-primary" disabled={loading}>{loading ? 'Creating...' : 'Create Lifafa'}</button>
        </div>
      </div>
    </div>
  );
}

function HelpTab() {
  return (
    <div className="space-y-4 mt-4">
      <div className="card text-center">
        <div className="text-4xl mb-3">💙</div>
        <h3 className="font-bold text-gray-700 mb-2">UNIO Wallet Support</h3>
        <p className="text-gray-500 text-sm mb-4">We're here to help you!</p>
        <div className="space-y-3">
          <a href="https://t.me/UNIOWALLET_OWNER" target="_blank"
            className="flex items-center gap-3 p-3 bg-blue-50 rounded-xl hover:bg-blue-100 transition">
            <span className="text-2xl">✈️</span>
            <div className="text-left">
              <p className="font-medium text-gray-700">Telegram Support</p>
              <p className="text-blue-600 text-sm">@UNIOWALLET_OWNER</p>
            </div>
          </a>
          <a href="mailto:sharmasumitji5141@gmail.com"
            className="flex items-center gap-3 p-3 bg-blue-50 rounded-xl hover:bg-blue-100 transition">
            <span className="text-2xl">📧</span>
            <div className="text-left">
              <p className="font-medium text-gray-700">Email Support</p>
              <p className="text-blue-600 text-sm">sharmasumitji5141@gmail.com</p>
            </div>
          </a>
        </div>
      </div>
    </div>
  );
}
