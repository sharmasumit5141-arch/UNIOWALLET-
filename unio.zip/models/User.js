import mongoose from 'mongoose';

const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  telegramId: { type: String, required: true },
  phone: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  walletNumber: { type: String, unique: true },
  apiKey: { type: String, unique: true },
  balance: { type: Number, default: 0 },
  banned: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.models.User || mongoose.model('User', UserSchema);
