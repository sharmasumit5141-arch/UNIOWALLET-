import mongoose from 'mongoose';

const TransactionSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  walletNumber: String,
  name: String,
  type: { type: String, enum: ['add', 'withdraw', 'transfer_in', 'transfer_out', 'bonus', 'lifafa'] },
  amount: Number,
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  utrNumber: String,
  mobileNumber: String,
  upiId: String,
  toWallet: String,
  fromWallet: String,
  transactionId: String,
  note: String,
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.models.Transaction || mongoose.model('Transaction', TransactionSchema);
