import mongoose from 'mongoose';

const LifafaSchema = new mongoose.Schema({
  creatorId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  type: { type: String, enum: ['scratch', 'toss', 'normal'] },
  totalUsers: Number,
  perUserAmount: Number,
  minAmount: Number,
  maxAmount: Number,
  rewardRange: String,
  channels: [{ username: String, link: String }],
  claimedBy: [{ userId: mongoose.Schema.Types.ObjectId, amount: Number, claimedAt: Date }],
  claimUrl: String,
  siteName: String,
  active: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.models.Lifafa || mongoose.model('Lifafa', LifafaSchema);
