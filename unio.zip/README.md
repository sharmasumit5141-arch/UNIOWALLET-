# UNIO Wallet 💙

## Deploy on Vercel - Step by Step

### Step 1 - MongoDB Atlas
1. Go to mongodb.com/atlas
2. Create free account
3. Create cluster (free tier)
4. Database Access → Add user
5. Network Access → Allow all (0.0.0.0/0)
6. Connect → Copy connection string

### Step 2 - Vercel Deploy
1. Go to vercel.com
2. Import this project folder
3. Add Environment Variables:
   - MONGODB_URI = (your MongoDB connection string)
   - JWT_SECRET = any_random_secret_key
   - TELEGRAM_BOT_TOKEN = 7507385917:AAG3MmJO2VlzJAfvyjKeu_hqfQ0F3dCztow
4. Deploy!

### Admin Panel
URL: yourdomain.vercel.app/admin
PIN: 5510

### API Usage
POST /api/balance
Body: { "api_key": "user_api_key", "wallet_number": "UW123" }

POST /api/deduct-money  
Body: { "api_key": "user_api_key", "wallet_number": "UW123", "amount": 10 }

POST /api/transfer
Body: { "api_key": "user_api_key", "wallet_number": "UW123", "toWallet": "UW456", "amount": 10 }
